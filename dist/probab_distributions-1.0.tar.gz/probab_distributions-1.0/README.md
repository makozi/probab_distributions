# probab_distributions
`probab_distributions`: Python Package for Gaussian and Binomial Distribution.


# License
[MIT License](https://github.com/makozi/probab_distributions/blob/master/LICENSE)


# Author
[Marizu-Ibewiro Makozi](marizumakozi97@gmail.com)
