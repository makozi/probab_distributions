from setuptools import setup

setup(name='probab_distributions',
      version='1.0',
      description='Gaussian and Binomial distribution',
      packages=['probab_distributions'],
      author='Marizu-Ibewiro Makozi',
      author_email='marizumakozi97@gmail.com',
      zip_safe=False)
